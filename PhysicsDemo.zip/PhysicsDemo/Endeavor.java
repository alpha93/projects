import javafx.animation.AnimationTimer;
import javafx.application.Application;
import javafx.event.EventHandler;
import javafx.geometry.Bounds;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.paint.Color;
import javafx.scene.shape.*;
import javafx.scene.transform.Scale;
import javafx.scene.transform.Translate;
import javafx.stage.Stage;
import org.jbox2d.collision.shapes.CircleShape;
import org.jbox2d.collision.shapes.PolygonShape;
import org.jbox2d.common.Vec2;
import org.jbox2d.dynamics.*;

import java.util.ArrayList;
import java.util.Random;

public class Endeavor extends Application {
    private final static int SCALE_FACTOR = 50;
    ArrayList<ShapesWithPhysics> objects = new ArrayList<>();

    public static void main(String args[]) {
        Converter.setScaleFactor(SCALE_FACTOR);
        launch();
    }

    public void start(Stage primaryStage) throws Exception {
        // create a rootNode and flip the Y-axis and bring the origin to the lower-left corner
        Group rootNode = new Group(new Rectangle(900, 600, Color.web("eee")));
        rootNode.getTransforms().addAll(new Scale(1, -1), new Translate(0, -600));

        Scene scene = new Scene(rootNode, 900, 600);

        // for this program, lets assume the scale factor to be 10 i.e. pixel world : box2d world = 10 : 1
        World world = new World(new Vec2(0f, -9.8f));
        world.setSleepingAllowed(true);
        //world.

        // create the land
        // STEP 1: create a body definition
        BodyDef landBodyDef = new BodyDef();
        landBodyDef.position.set(Converter.pixelToWorld(450), Converter.pixelToWorld(-10));
        landBodyDef.type = BodyType.STATIC;

        // STEP 2: create a Body by passing the body definition to the world
        Body landBody = world.createBody(landBodyDef);

        // STEP 3: create a shape for the land
        PolygonShape landShape = new PolygonShape();
        landShape.setAsBox(Converter.pixelToWorld(450), Converter.pixelToWorld(10));   // pass half the intended height and width

        // STEP 4: add the shape to the body using a fixture
        landBody.createFixture(landShape, 0);

        rootNode.setOnMouseDragged(new EventHandler<MouseEvent>() {
            int chance;

            @Override
            public void handle(MouseEvent event) {
                chance = (int) (Math.random()*10);

                if(chance < 3) {
                    RectangleWithPhysics rect = new RectangleWithPhysics(world, (float)event.getX(), (float)event.getY());
                    rootNode.getChildren().add(rect);
                    objects.add(rect);
                } else if(chance < 6) {
                    CircleWithPhysics circle = new CircleWithPhysics(world, (float)event.getX(), (float)event.getY());
                    rootNode.getChildren().add(circle);
                    objects.add(circle);
                }
//                else {
//                    TriangleWithPhysics triangle = new TriangleWithPhysics(world, (float)event.getX(), (float)event.getY());
//                    rootNode.getChildren().add(triangle);
//                    objects.add(triangle);
//                }
            }
        });

        AnimationTimer gameLoop = new AnimationTimer() {
            int count = 0;

            @Override
            public void handle(long now) {
                world.step((float)(1.0/60), 10, 15);

                for(int i=0; i<objects.size(); ) {
                    ShapesWithPhysics object = objects.get(i);

                    // remove the ShapeWithPhysics object from both the list of objects and the scene graph if the
                    // update method returns false, which it does when the object goes beyond scene dimensions. Failing
                    // to remove these objects will hurt performance
                    if(!object.update()) {
                        objects.remove(object);
                        rootNode.getChildren().remove(object);
                    } else {
                        i++;
                    }
                }

            }
        };

        primaryStage.setTitle("Physics Demo");
        primaryStage.setScene(scene);
        primaryStage.getIcons().add(new Image("logo.png"));
        primaryStage.setResizable(false);
        primaryStage.sizeToScene();
        primaryStage.show();

        gameLoop.start();
    }
}

class Converter {
    private static int scaleFactor;

    // making the methods final, may give them a performance benefit (Early Binding)
    static final void setScaleFactor(int scaleFactor) {
        Converter.scaleFactor = scaleFactor;    // cannon use "this" because its a static method
    }

    static final float pixelToWorld(float pixelValue) {
        return pixelValue/scaleFactor;
    }

    static final float worldToPixel(float worldValue) {
        return worldValue*scaleFactor;
    }

//    static double map(double val, double fromLower, double fromUpper, double toLower, double toUpper) {
//        return (toUpper - toLower)/(fromUpper - fromLower) * (val-fromLower) + toLower;
//    }
}

// using this interface allows to store all the shapes in a single ArrayList
interface ShapesWithPhysics {
    boolean update();
}

class RectangleWithPhysics extends Rectangle implements ShapesWithPhysics {
    private static Random random = new Random();
    private Body body;
    private World world;
    private float width, height;

    {
        width = random.nextInt(31) + 10;
        height = random.nextInt(21) + 10;
    }

    RectangleWithPhysics(World world, float posX, float posY) {
        // Graphics rectangle
        super();
        setWidth(width);
        setHeight(height);
        setFill(Color.CORNFLOWERBLUE);
        setTranslateX(posX);
        setTranslateY(posY);
        setStroke(Color.web("222"));
        setStrokeWidth(3);
        setStrokeType(StrokeType.INSIDE);
        setSmooth(true);

        this.world = world;

        // JBox2D rectangle
        BodyDef bodyDef = new BodyDef();
        bodyDef.position.set(Converter.pixelToWorld(posX), Converter.pixelToWorld(posY));
        bodyDef.type = BodyType.DYNAMIC;
        bodyDef.allowSleep = true;

        body = world.createBody(bodyDef);

        PolygonShape box = new PolygonShape();
        box.setAsBox(Converter.pixelToWorld(width/2), Converter.pixelToWorld(height/2));

        FixtureDef fixtureDef = new FixtureDef();
        fixtureDef.shape = box;
        fixtureDef.friction = 0.2f;
        fixtureDef.density = 2f;
        fixtureDef.restitution = 0.5f;

        body.createFixture(fixtureDef);
    }

    public boolean update() {
        Vec2 position = body.getPosition();

        // delete the object if it gets out of the window so the physics world doesn't have to simulate them anymore
        // I have taken 100 pixels extra, because the positions are measured form thr center
        if(position.x > Converter.pixelToWorld(1000) || position.x < Converter.pixelToWorld(-100)
                || position.y < Converter.pixelToWorld(-100)) {
            world.destroyBody(body);
            body = null;

            return false;
        }

        // adjustments need to be made for the fact that JBox2D measures position form the geometric center and JavaFX
        // measures from the bottom left corner (because of the flipped Y-axis). Apparently subtracting half the width
        // and height from the position returned by the world object, works, although I;m not entirely sure how.
        setTranslateX(Converter.worldToPixel(position.x) - width/2);
        setTranslateY(Converter.worldToPixel(position.y) - height/2);

        // the -ve sign is to compensate for the fact that clockwise in the physics world is counter-clockwise in the
        // graphics world
        setRotate(-Math.toDegrees(body.getAngle()));

        return true;
    }
}

class CircleWithPhysics extends Circle implements ShapesWithPhysics {
    private static Random random = new Random();
    private Body body;
    private World world;
    private float radius;

    {
        radius = random.nextInt(21) + 10;
    }

    CircleWithPhysics(World world, float centerX, float centerY) {
        // Graphics circle
        super();
        setCenterX(centerX);
        setCenterY(centerY);
        setFill(Color.ORANGE);
        setRadius(radius);
        setStroke(Color.web("222"));
        setStrokeWidth(3);
        setStrokeType(StrokeType.INSIDE);
        setSmooth(true);

        this.world = world;

        // JBox2D circle
        BodyDef bodyDef = new BodyDef();
        bodyDef.position.set(Converter.pixelToWorld(centerX), Converter.pixelToWorld(centerY));
        bodyDef.type = BodyType.DYNAMIC;
        bodyDef.allowSleep = true;

        body = world.createBody(bodyDef);

        CircleShape circleShape = new CircleShape();
        circleShape.m_radius = Converter.pixelToWorld(radius);

        FixtureDef fixtureDef = new FixtureDef();
        fixtureDef.shape = circleShape;
        fixtureDef.friction = 0.2f;
        fixtureDef.density = 2;
        fixtureDef.restitution = 0.8f;

        body.createFixture(fixtureDef);
    }

    public boolean update() {
        Vec2 position = body.getPosition();

        if(position.x > Converter.pixelToWorld(1000) || position.x < Converter.pixelToWorld(-100)
                || position.y < Converter.pixelToWorld(-100)) {
            world.destroyBody(body);
            body = null;

            return false;
        }

        setCenterX(Converter.worldToPixel(position.x));
        setCenterY(Converter.worldToPixel(position.y));

        setRotate(-Math.toDegrees(body.getAngle()));

        return true;
    }
}

class TriangleWithPhysics extends Polygon implements ShapesWithPhysics {
    private Body body;
    private World world;

    TriangleWithPhysics(World world, float posX, float posY) {
        super(0, 0, 15, Math.sqrt(3)/2*30, 30, 0);
        setTranslateX(posX);
        setTranslateY(posY);
        setFill(Color.SPRINGGREEN);
        setStroke(Color.web("222"));
        setStrokeWidth(3);
        setStrokeType(StrokeType.INSIDE);
        setSmooth(true); //setRotate(-30);

        this.world = world;

        // JBox2D body
        BodyDef bodyDef = new BodyDef();
        bodyDef.position.set(Converter.pixelToWorld(posX), Converter.pixelToWorld(posY));
        bodyDef.type = BodyType.DYNAMIC; //bodyDef.angle = (float)Math.toRadians(30);
        bodyDef.allowSleep = true;

        body = world.createBody(bodyDef);

        PolygonShape triangleShape = new PolygonShape();
        Vec2 points[] = {
                new Vec2(Converter.pixelToWorld(-15), Converter.pixelToWorld(-15)),
                new Vec2(Converter.pixelToWorld(15), Converter.pixelToWorld(-15)),
                new Vec2(Converter.pixelToWorld(0), Converter.pixelToWorld(15))};
        triangleShape.set(points, 3);

        FixtureDef fixtureDef = new FixtureDef();
        fixtureDef.shape = triangleShape;
        fixtureDef.density = 2;
        fixtureDef.restitution = 0.2f;
        fixtureDef.friction = 0.2f;

        body.createFixture(fixtureDef);
    }

    public boolean update() {
        Vec2 position = body.getPosition();

        if(position.x > Converter.pixelToWorld(1000) || position.x < Converter.pixelToWorld(-100)
                || position.y < Converter.pixelToWorld(-100)) {
            world.destroyBody(body);
            body = null;

            return false;
        }

        setTranslateX(Converter.worldToPixel(position.x) - 15);
        setTranslateY(Converter.worldToPixel(position.y) - 15);

        setRotate(- Math.toDegrees(body.getAngle()));

        return true;
    }
}